package com.example.voiceassistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ExifInterface
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** बिना स्क्रीन पर प्रीव्यू दिखाए कैमरे से एक तस्वीर लेता है (सेल्फ़ी या पीछे वाला कैमरा) */
object CameraGrab {

    /** front = true: सेल्फ़ी कैमरा। सीधी, छोटी JPEG लौटाता है, या null अगर कैमरा न खुले */
    @SuppressLint("MissingPermission")
    fun capture(ctx: Context, front: Boolean): ByteArray? {
        if (ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return null
        val cm = ctx.getSystemService(CameraManager::class.java)
        val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        val id: String = (try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want
            }
        } catch (e: Exception) { null }) ?: return null
        val chars = cm.getCameraCharacteristics(id)
        val sensor = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return null

        val jpegSizes = map.getOutputSizes(ImageFormat.JPEG) ?: return null
        val jSize: Size = jpegSizes.filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }
            ?: jpegSizes.minByOrNull { it.width * it.height } ?: return null
        val pSizes = map.getOutputSizes(SurfaceTexture::class.java)
        val pSize: Size = pSizes?.filter { it.width <= 640 }?.maxByOrNull { it.width * it.height }
            ?: pSizes?.firstOrNull() ?: Size(640, 480)

        val ht = HandlerThread("cam-grab").apply { start() }
        val h = Handler(ht.looper)
        val reader = ImageReader.newInstance(jSize.width, jSize.height, ImageFormat.JPEG, 2)
        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var jpeg: ByteArray? = null
        val got = CountDownLatch(1)

        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    if (jpeg == null) { jpeg = bytes; got.countDown() }
                } finally { img.close() }
            }
        }, h)

        try {
            val opened = CountDownLatch(1)
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { device = d; opened.countDown() }
                override fun onDisconnected(d: CameraDevice) { d.close(); opened.countDown() }
                override fun onError(d: CameraDevice, e: Int) { d.close(); opened.countDown() }
            }, h)
            if (!opened.await(4, TimeUnit.SECONDS)) return null
            val dev = device ?: return null

            val st = SurfaceTexture(0).apply { setDefaultBufferSize(pSize.width, pSize.height) }
            val preview = Surface(st)
            val configured = CountDownLatch(1)
            dev.createCaptureSession(listOf(preview, reader.surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) { session = s; configured.countDown() }
                    override fun onConfigureFailed(s: CameraCaptureSession) { configured.countDown() }
                }, h)
            if (!configured.await(4, TimeUnit.SECONDS)) return null
            val s = session ?: return null

            // एक्सपोज़र सेट होने के लिए थोड़ी देर प्रीव्यू चलाओ, फिर तस्वीर लो
            val prev = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(preview) }
            s.setRepeatingRequest(prev.build(), null, h)
            Thread.sleep(900)
            val still = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(reader.surface)
                set(CaptureRequest.JPEG_ORIENTATION, sensor)
            }
            s.capture(still.build(), null, h)
            got.await(4, TimeUnit.SECONDS)
            return jpeg?.let { upright(it) }
        } catch (e: Exception) {
            return null
        } finally {
            try { session?.close() } catch (_: Exception) { }
            try { device?.close() } catch (_: Exception) { }
            try { reader.close() } catch (_: Exception) { }
            ht.quitSafely()
        }
    }

    /** तस्वीर को सीधा (EXIF के हिसाब से घुमाकर) और छोटा (अधिकतम 960px) करके JPEG बनाता है */
    fun upright(src: ByteArray): ByteArray {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(src, 0, src.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1920) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(
                src, 0, src.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return src
            val rot = try {
                when (ExifInterface(ByteArrayInputStream(src))
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } catch (e: Exception) { 0 }
            var out = bmp
            if (rot != 0) {
                out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                    Matrix().apply { postRotate(rot.toFloat()) }, true)
            }
            val m = maxOf(out.width, out.height)
            if (m > 960) {
                val f = 960f / m
                out = Bitmap.createScaledBitmap(out, (out.width * f).toInt(), (out.height * f).toInt(), true)
            }
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            bos.toByteArray()
        } catch (e: Exception) { src }
    }
}
